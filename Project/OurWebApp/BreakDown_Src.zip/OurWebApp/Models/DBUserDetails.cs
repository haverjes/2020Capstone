﻿using System.Collections.Generic;
using Newtonsoft.Json;

namespace OurWebApp.Models
{
    [System.CodeDom.Compiler.GeneratedCode("NJsonSchema", "10.1.5.0 (Newtonsoft.Json v12.0.0.0)")]
    public partial class DBUserDetails : UserDetails
    {
        public MongoDB.Bson.ObjectId _id;

        public DBUserDetails(UserDetails user)
        {
            

        }

    }
}