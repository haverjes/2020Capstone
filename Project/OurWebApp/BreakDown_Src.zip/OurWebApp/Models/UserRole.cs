﻿namespace OurWebApp.Models
{
    [System.CodeDom.Compiler.GeneratedCode("NJsonSchema", "10.1.5.0 (Newtonsoft.Json v12.0.0.0)")]
    public enum UserRole
    {
        [System.Runtime.Serialization.EnumMember(Value = @"Driver")]
        Driver = 0,

        [System.Runtime.Serialization.EnumMember(Value = @"Customer")]
        Customer = 1,

        [System.Runtime.Serialization.EnumMember(Value = @"Dispatcher")]
        Dispatcher = 2,

    }
}